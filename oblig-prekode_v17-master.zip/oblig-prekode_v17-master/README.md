# Prekode for obliger våren 2017
