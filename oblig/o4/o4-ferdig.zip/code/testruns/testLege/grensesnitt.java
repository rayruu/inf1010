
interface Kommuneavtale {
    public int hentAvtalenummer();
}
