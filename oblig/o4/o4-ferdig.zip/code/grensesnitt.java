/**
 * Fastleger har en unik kommuneavtale med sine pasienter.
 * @author Stein Raymond Rudshagen
 * @version 1.0 16. mars 2017
 */
interface Kommuneavtale {
    public int hentAvtalenummer();
}
