Last ned disse filene og legg dem i samme mappe som koden din.

## Kommandoer for å laste ned og pakke ut filene automatisk
Disse kommandoene bør fungere på Linux og Mac. Sørg for at du er i riktig mappe.

### Med zip
```sh
wget http://folk.uio.no/inf1010/v17/oblig/3/prekode.zip
unzip prekode.zip
```

### Med tarball
```sh
wget http://folk.uio.no/inf1010/v17/oblig/3/prekode.tgz
tar -xvf prekode.tgz
```
